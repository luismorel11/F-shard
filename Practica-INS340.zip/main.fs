open System

[<EntryPoint>]
let main argv =
    printfn "Hola mundo desde F#"
    0
